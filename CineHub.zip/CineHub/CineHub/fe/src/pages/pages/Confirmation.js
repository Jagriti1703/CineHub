export default function Confirmation({ onNext, seatSelection }) {
  return (
    <div className="App">
      <h1>Hello Confirmation</h1>
      <h2>Start editing to see some magic happen!</h2>
    </div>
  );
}
